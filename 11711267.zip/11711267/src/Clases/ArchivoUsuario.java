/*
Titulo: Clase ArchivoUsuario

Funcion: contiene las funciones para administrar el archivo de texto

Fecha: 13 de agosto del 2018

Elaborado por: Martín José Pérez Gálvez
 */
package Clases;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class ArchivoUsuario {

    private String nombre;
    private ArrayList<Arista> listaArista = new ArrayList();
    private File archivo = null;

    //Constructor ArchivoUsuario
/*
    Aqui se incializa el archivo de ArchivoUsuario
  
    Parametros: String path, es la ruta de alrchivo
    
    Retorna:
    
    Errores: 
    
     */
    public ArchivoUsuario(String path) {
        archivo = new File(path);
    }
    
    
    
  //Constructor ArchivoUsuario simple

    public ArchivoUsuario() {
    }

    
    
    //Funcion setArchivo
/*
    Aqui se asigna un archivo al archivo de Archivo Usuario
  
    Parametros: File archivo, es el archivo que se asiganara
    
    Retorna:
    
    Errores: 
    
     */
    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

     //Funcion getListaArista
/*
    Aqui se devuelve la lista de Aristas
  
    Parametros:
    
    Retorna: La lista de aristas
    
    Errores: 
    
     */
    public ArrayList<Arista> getListaArista() {
        return listaArista;
    }
    
    
     //Funcion setListaArista
/*
    Aqui se asigna la lista de aristas
  
    Parametros: un ArrayList el cual es la lista de Aristas
    
    Retorna: 
    
    Errores: 
    
     */

    public void setListaArista(ArrayList<Arista> listaArista) {
        this.listaArista = listaArista;
    }

    
     //Funcion escribir archivo
/*
    Aqui se administra el guardado del archivo de texto
  
    Parametros: 
    
    Retorna: 
    
    Errores: 
    
     */
    public void escribirArchivo() throws IOException {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(archivo, false);
            bw = new BufferedWriter(fw);

            for (Arista t : listaArista) {
                bw.write(t.getUsuario1() + ",");
                bw.write(t.getUsuario2() + ",");
                String temp=t.getPeso()+"";
                bw.write(temp);
                bw.write("\n");
            }

            bw.flush();
        } catch (Exception e) {

        }
        bw.close();
        fw.close();
    }
    
     //Funcion cargar archivo
/*
    Aqui se administra la carga del archivo de texto
  
    Parametros: 
    
    Retorna: 
    
    Errores: 
    
     */

    public void cargarArchivo() {

        if (archivo.exists()) {
            Scanner sc = null;
            listaArista = new ArrayList();

            try {
                sc = new Scanner(archivo);
                sc.useDelimiter("\n");

                while (sc.hasNext()) {
                    String temp=sc.next();
                   
                    
                    listaArista.add(new Arista(temp.split(",")[0], temp.split(",")[1],Integer.parseInt(temp.split(",")[2])));
                    
                }
                
                

            } catch (Exception e) {
            }

            sc.close();
        }//Fin del if 
    }

}//Fin de la clase
