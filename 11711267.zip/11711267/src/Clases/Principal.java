/*
Titulo: Proyecto 3, proyecto libre usando Grafos

Proposito: Aplicar teoria de grafos para soluciones en la vida real y
           utilizar librerias de terceros en este caso Graphstream

Fecha: 13 de agosto del 2018

Clase: Estrucutura de datos I

Elaborado por: Martìn Jòse Pèrez Gàlvez
 */
package Clases;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;
import org.graphstream.algorithm.Dijkstra;
import org.graphstream.algorithm.Prim;
import org.graphstream.ui.swingViewer.ViewPanel;
import org.graphstream.ui.view.Viewer;

public class Principal extends javax.swing.JFrame {

    public Principal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jd_menu = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jlb_nombre = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jl_amigos = new javax.swing.JList<>();
        jLabel5 = new javax.swing.JLabel();
        jb_refrescar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jb_salirContacto = new javax.swing.JButton();
        jb_establecerCercanias = new javax.swing.JButton();
        jb_nuevoContacto = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jm_abrirArchivo = new javax.swing.JMenuItem();
        jm_guardarArchivo = new javax.swing.JMenuItem();
        jd_asignarUsuario = new javax.swing.JDialog();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        tf_nombreContacto = new javax.swing.JTextField();
        jb_agregarUsuario = new javax.swing.JButton();
        jpp_contactos = new javax.swing.JPopupMenu();
        jm_eliminar = new javax.swing.JMenuItem();
        jd_cercania = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jl_viveYo = new javax.swing.JList<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        jl_vive1 = new javax.swing.JList<>();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jl_vive2 = new javax.swing.JList<>();
        jb_cercania1 = new javax.swing.JButton();
        jb_cercania2 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        tf_distancia1 = new javax.swing.JTextField();
        tf_distancia2 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jd_grafo = new javax.swing.JDialog();
        jPanel5 = new javax.swing.JPanel();
        jp_grafo = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jb_salidaRapida = new javax.swing.JButton();
        jb_calcularRutaCorta = new javax.swing.JButton();
        cb_contactos2 = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        cb_contactos1 = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jb_ruta = new javax.swing.JLabel();
        jb_ruta1 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Inicio_boton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        tf_nombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tf_celular = new javax.swing.JTextField();

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setForeground(new java.awt.Color(153, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(jlb_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 10, 180, 20));

        jl_amigos.setModel(new DefaultListModel());
        jl_amigos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_amigosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jl_amigos);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, 360, 180));

        jLabel5.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel5.setText("Menu Contactos");
        jLabel5.setToolTipText("");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, 220, -1));

        jb_refrescar.setText("Refrescar Listado");
        jb_refrescar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_refrescarMouseClicked(evt);
            }
        });
        jb_refrescar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_refrescarActionPerformed(evt);
            }
        });
        jPanel2.add(jb_refrescar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 330, -1, -1));

        jLabel10.setBackground(new java.awt.Color(255, 0, 51));
        jLabel10.setForeground(new java.awt.Color(255, 0, 51));
        jLabel10.setText("*click derecho eliminar contactos");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, -1, -1));

        jb_salirContacto.setText("Salir con contacto");
        jb_salirContacto.setToolTipText("* Despliega el grafo y permite tomar opciones con el");
        jb_salirContacto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_salirContactoMouseClicked(evt);
            }
        });
        jPanel2.add(jb_salirContacto, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 410, -1, 70));

        jb_establecerCercanias.setText("Establecer cercanias entre contactos");
        jb_establecerCercanias.setToolTipText("*Permite formar arista nuevas");
        jb_establecerCercanias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_establecerCercaniasMouseClicked(evt);
            }
        });
        jb_establecerCercanias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_establecerCercaniasActionPerformed(evt);
            }
        });
        jPanel2.add(jb_establecerCercanias, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 410, -1, 70));

        jb_nuevoContacto.setText("Nuevo contacto");
        jb_nuevoContacto.setToolTipText("*Crea un nuevo contacto (Nodo)");
        jb_nuevoContacto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_nuevoContactoMouseClicked(evt);
            }
        });
        jPanel2.add(jb_nuevoContacto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 410, 120, 70));

        jLabel9.setForeground(new java.awt.Color(255, 51, 51));
        jLabel9.setText("*Leer los toolTip text de los botones");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 60, -1, -1));

        jMenu1.setText("Contactos");

        jm_abrirArchivo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        jm_abrirArchivo.setText("Abrir Archivo");
        jm_abrirArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jm_abrirArchivoActionPerformed(evt);
            }
        });
        jMenu1.add(jm_abrirArchivo);

        jm_guardarArchivo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jm_guardarArchivo.setText("Guardar Archivo");
        jm_guardarArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jm_guardarArchivoActionPerformed(evt);
            }
        });
        jMenu1.add(jm_guardarArchivo);

        jMenuBar1.add(jMenu1);

        jd_menu.setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout jd_menuLayout = new javax.swing.GroupLayout(jd_menu.getContentPane());
        jd_menu.getContentPane().setLayout(jd_menuLayout);
        jd_menuLayout.setHorizontalGroup(
            jd_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 873, Short.MAX_VALUE)
        );
        jd_menuLayout.setVerticalGroup(
            jd_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(153, 153, 153));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("Nuevo Contacto");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/71-1436214917.png"))); // NOI18N

        jLabel8.setText("Nombre:");

        jb_agregarUsuario.setText("Agregar");
        jb_agregarUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_agregarUsuarioMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(41, 41, 41)
                        .addComponent(tf_nombreContacto, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(124, 124, 124))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jb_agregarUsuario)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(12, 12, 12)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_nombreContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(jb_agregarUsuario)
                .addContainerGap())
        );

        javax.swing.GroupLayout jd_asignarUsuarioLayout = new javax.swing.GroupLayout(jd_asignarUsuario.getContentPane());
        jd_asignarUsuario.getContentPane().setLayout(jd_asignarUsuarioLayout);
        jd_asignarUsuarioLayout.setHorizontalGroup(
            jd_asignarUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jd_asignarUsuarioLayout.setVerticalGroup(
            jd_asignarUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jm_eliminar.setText("Eliminar contacto");
        jm_eliminar.setToolTipText("");
        jm_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jm_eliminarActionPerformed(evt);
            }
        });
        jpp_contactos.add(jm_eliminar);

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("Cercanias");

        jLabel12.setText("Yo vivo cerca de:");

        jl_viveYo.setModel(new DefaultListModel());
        jScrollPane2.setViewportView(jl_viveYo);

        jl_vive1.setModel(new DefaultListModel());
        jScrollPane3.setViewportView(jl_vive1);

        jLabel13.setText("vive cerca de: ");

        jl_vive2.setModel(new DefaultListModel());
        jScrollPane4.setViewportView(jl_vive2);

        jb_cercania1.setText("Establecer Cercania");
        jb_cercania1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_cercania1MouseClicked(evt);
            }
        });
        jb_cercania1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_cercania1ActionPerformed(evt);
            }
        });

        jb_cercania2.setText("Establecer Cercania");
        jb_cercania2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_cercania2MouseClicked(evt);
            }
        });
        jb_cercania2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_cercania2ActionPerformed(evt);
            }
        });

        jLabel15.setText("Distancia");

        tf_distancia1.setToolTipText("");

        jLabel16.setText("Distancia: ");

        jLabel17.setText("---------------------------------------------------------------------------------------------------------------------------");

        jLabel18.setText("Km");

        jLabel19.setText("Km");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(260, 260, 260))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(82, 82, 82)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(156, 156, 156)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(tf_distancia1, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel18))))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(213, 213, 213)
                                .addComponent(jb_cercania1))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jb_cercania2))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(187, 187, 187)
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addComponent(tf_distancia2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tf_distancia1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel18)))
                .addGap(18, 18, 18)
                .addComponent(jb_cercania1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_distancia2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)
                            .addComponent(jLabel19))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(143, 143, 143))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jb_cercania2)
                                .addGap(142, 142, 142))))))
        );

        javax.swing.GroupLayout jd_cercaniaLayout = new javax.swing.GroupLayout(jd_cercania.getContentPane());
        jd_cercania.getContentPane().setLayout(jd_cercaniaLayout);
        jd_cercaniaLayout.setHorizontalGroup(
            jd_cercaniaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jd_cercaniaLayout.setVerticalGroup(
            jd_cercaniaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jd_grafo.setBackground(new java.awt.Color(153, 153, 153));
        jd_grafo.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jp_grafo.setBackground(new java.awt.Color(102, 102, 102));
        jp_grafo.setPreferredSize(new java.awt.Dimension(600, 600));

        javax.swing.GroupLayout jp_grafoLayout = new javax.swing.GroupLayout(jp_grafo);
        jp_grafo.setLayout(jp_grafoLayout);
        jp_grafoLayout.setHorizontalGroup(
            jp_grafoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );
        jp_grafoLayout.setVerticalGroup(
            jp_grafoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setText("Salida con Contactos");

        jb_salidaRapida.setText("Salida Rapida");
        jb_salidaRapida.setToolTipText("Calcula el mejor camino a seguir para ir con cualquier contacto");
        jb_salidaRapida.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_salidaRapidaMouseClicked(evt);
            }
        });

        jb_calcularRutaCorta.setText("Calcular");
        jb_calcularRutaCorta.setToolTipText("Marca los contactos por los cuales se garantiza una ruta mas corta");
        jb_calcularRutaCorta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_calcularRutaCortaMouseClicked(evt);
            }
        });

        jLabel20.setText("hasta");

        jLabel21.setText("Desde");

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("Ruta mas corta");

        jb_ruta.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jb_ruta.setText("--------------------------------------------------------------------------------------------------------------------------");

        jb_ruta1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jb_ruta1.setText("--------------------------------------------------------------------------------------------------------------------------");

        jLabel23.setBackground(new java.awt.Color(255, 0, 51));
        jLabel23.setForeground(new java.awt.Color(255, 0, 0));
        jLabel23.setText("*leer toolTip texts");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(322, 322, 322)
                        .addComponent(jLabel14)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel23))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jb_salidaRapida)
                        .addGap(237, 237, 237)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cb_contactos1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel20)
                        .addGap(18, 18, 18)
                        .addComponent(cb_contactos2, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jb_calcularRutaCorta)))
                .addContainerGap(31, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(51, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jb_ruta1, javax.swing.GroupLayout.PREFERRED_SIZE, 889, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jb_ruta, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addComponent(jp_grafo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addGap(279, 279, 279))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jLabel23))
                .addGap(5, 5, 5)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jb_salidaRapida)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cb_contactos1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel20)
                        .addComponent(cb_contactos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jb_calcularRutaCorta)
                        .addComponent(jLabel21)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(jb_ruta1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jb_ruta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jp_grafo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jp_grafo.getAccessibleContext().setAccessibleDescription("");

        jd_grafo.getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 810));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("TI-Nspire", 3, 48)); // NOI18N
        jLabel1.setText("Localizador de Contactos");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 540, 60));

        Inicio_boton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Inicio_boton.setText("Ingresar");
        Inicio_boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Inicio_botonMouseClicked(evt);
            }
        });
        jPanel1.add(Inicio_boton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 370, 200, 55));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Bienvenido estimado usuario");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, -1, -1));
        jPanel1.add(tf_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 200, 210, -1));

        jLabel3.setText("Ingrese su nombre:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, -1, -1));

        jLabel4.setText("Ingrese su numero de telefono:");
        jLabel4.setToolTipText("");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 260, -1, -1));
        jPanel1.add(tf_celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 260, 210, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 821, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//Funcion mouseClicked boton inicio
/*
    Boton que inicia el programa y conduce a la pantalla principal al hacerle click
    Guarda nombre el usuario y su telefono en una variable
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si se presiona otra tecla que no se la solicitada no ocurre nada
    
     */
    private void Inicio_botonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Inicio_botonMouseClicked

        nombrePrincipal = tf_nombre.getText();
        celularPrincipal = tf_celular.getText();

        jlb_nombre.setText(tf_nombre.getText() + " - " + tf_celular.getText());

        this.jd_menu.setModal(true);
        jd_menu.pack();
        jd_menu.setLocationRelativeTo(this);
        jd_menu.setVisible(true);


    }//GEN-LAST:event_Inicio_botonMouseClicked
//Funcion Boton Abrir archivo
/*
    Boton que abre un JFileChooser para elegir de donde abrir el archivo de texto que tendra los datos del programa
    Aqui tambien se llena la lista de Usuarios(Contactos)
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si se presiona otra tecla que no se la solicitada no ocurre nada, si el JFileChooser se cierra
             o no se abre correctamente no se elegira ningun archivo
    
     */
    private void jm_abrirArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jm_abrirArchivoActionPerformed
        // TODO add your handling code here:
        JFileChooser jfc = new JFileChooser();
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos de Texto", "txt");
        jfc.addChoosableFileFilter(filtro);
        int seleccion = jfc.showOpenDialog(this);

        FileWriter fw = null;
        BufferedWriter bw = null;
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            try {
                File fichero = null;
                archivo = new File(jfc.getSelectedFile().getPath());
                ruta = jfc.getSelectedFile().getPath() + ".txt";

                archivoUsuario.setArchivo(archivo);
                archivoUsuario.cargarArchivo();
                listaArista = archivoUsuario.getListaArista();
                //Aumentar el contador por la raiz
                cont++;
                listaUsuarios = new ArrayList();
                graph = new SingleGraph("Grafo");
                graph.setStrict(false);
                graph.setAutoCreate(true);

                for (Arista t : listaArista) {

                    t.completar();
                    graph.addEdge(t.getEdge(), t.getUsuario1(), t.getUsuario2()).addAttribute("length", t.getPeso());
                    graph.getEdge(t.getEdge()).addAttribute("weight", t.getPeso());
                    if (t.getUsuario1().equals("Mi posicion actual") || t.getUsuario1().equals("Mi posicion actual")) {

                    } else {
                        listaUsuarios.add(new Usuario(t.getUsuario1()));
                        listaUsuarios.add(new Usuario(t.getUsuario2()));
                    }

                }

                //listaUsuarios = new ArrayList<Usuario>(new HashSet<Usuario>(listaUsuarios));
                ///
                ArrayList<String> temp = new ArrayList();

                for (Usuario l : listaUsuarios) {
                    if (!temp.contains(l.getNombre())) {
                        temp.add(l.getNombre());
                    }
                }

                listaUsuarios.clear();

                for (String s : temp) {
                    listaUsuarios.add(new Usuario(s));

                }

                //
                JOptionPane.showMessageDialog(jd_menu, "Archivo cargado exitosamente");

            } catch (Exception e) {

            }

        }
    }//GEN-LAST:event_jm_abrirArchivoActionPerformed
//Funcion Boton agregar un nuevo Usuario(Contacto)
/*
    Boton que agrega un nuevo Usuario(Contacto) con los datos del textField
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si no hay ningun texto en el textfiel no ocurrira nada
    
     */
    
  
     
    private void jb_agregarUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_agregarUsuarioMouseClicked
        // TODO add your handling code here:

        if (tf_nombreContacto.getText().equals("")) {
            JOptionPane.showMessageDialog(jd_asignarUsuario, "No ingreso ningun texto");
        } else {

            String nombre = tf_nombreContacto.getText();
            Usuario user = new Usuario(nombre);
            listaUsuarios.add(user);
            JOptionPane.showMessageDialog(jd_asignarUsuario, "Contacto agregado correctamente");
            tf_nombreContacto.setText("");

            graph.addNode(nombre);

            for (Node node : graph) {//Agrega las etiquetas
                node.addAttribute("ui.label", node.getId());

            }
        }


    }//GEN-LAST:event_jb_agregarUsuarioMouseClicked
//Funcion show popup Menu
/*
    Al hacer click derecho en la lista se mostrara un popup Menu para eliminar a cualquier contacto
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si no se presiona la tecla solicitada no pasara nada
    
     */
    private void jl_amigosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_amigosMouseClicked
        // TODO add your handling code here:
        if (evt.isMetaDown()) {
            jpp_contactos.show(evt.getComponent(), evt.getX(), evt.getY());
        }

    }//GEN-LAST:event_jl_amigosMouseClicked

//Funcion Eliminar Contacto
/*
    Elimina el contacto selecionado
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Al no seleccionar nada no se eliminara nada
    
     */
    private void jm_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jm_eliminarActionPerformed
        // TODO add your handling code here:
        int index;
        index = jl_amigos.getSelectedIndex();
        String temp = jl_amigos.getSelectedValue().getNombre();
        listaUsuarios.remove(index);

        jl_amigos.setModel(new DefaultListModel());
        DefaultListModel modelo = (DefaultListModel) jl_amigos.getModel();

        for (Usuario l : listaUsuarios) {
            modelo.addElement(l);

        }
        jl_amigos.setModel(modelo);

        graph.removeNode(temp);

        JOptionPane.showMessageDialog(jd_menu, "Contacto eliminado con exito");
    }//GEN-LAST:event_jm_eliminarActionPerformed

    //Funcion Guardar archivo
/*
    Guarda la lista de Aristas en un archivo de texto con JFileChooser
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si se cierra o no se seleciona nada en el JFileChooser no ocurrira nada
    
     */
    private void jm_guardarArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jm_guardarArchivoActionPerformed
        // TODO add your handling code here:
        
        JOptionPane.showMessageDialog(jd_menu, "No es necesario escribir la extensión al final");
        JFileChooser jfc = new JFileChooser();
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos de Texto", "txt");
        jfc.addChoosableFileFilter(filtro);
        int seleccion = jfc.showSaveDialog(this);

        if (seleccion == JFileChooser.APPROVE_OPTION) {
            try {

                archivo = new File(jfc.getSelectedFile().getPath() + ".txt");
                ruta = jfc.getSelectedFile().getPath();

                archivoUsuario.setListaArista(listaArista);
                archivoUsuario.setArchivo(archivo);
                archivoUsuario.escribirArchivo();

                JOptionPane.showMessageDialog(this, "Archivo Guardado con exito");

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }//GEN-LAST:event_jm_guardarArchivoActionPerformed

    private void jb_refrescarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_refrescarActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_jb_refrescarActionPerformed

     //Funcion Refrescar lista principal
/*
    Refresca la lista principal con el arrayList de usuarios, muestra el toString de estos en la JList
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: 
    
     */
    private void jb_refrescarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_refrescarMouseClicked
        // TODO add your handling code here:
        jl_amigos.setModel(new DefaultListModel());
        DefaultListModel modelo = (DefaultListModel) jl_amigos.getModel();

        for (Usuario l : listaUsuarios) {
            modelo.addElement(l);

        }
        jl_amigos.setModel(modelo);

        JOptionPane.showMessageDialog(jd_menu, "La lista se ha refrescado");
    }//GEN-LAST:event_jb_refrescarMouseClicked

      //Funcion Boton Salir con Contacto
/*
    Despliega un JDialog el cual es el que contiene el grafo con el cual se realizaran todas las tareas de grafos
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: 
    
     */
    private void jb_salirContactoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_salirContactoMouseClicked
        jb_ruta.setText("--------------------------------------------------------------------------------------------------------------------------");
        jb_ruta1.setText("--------------------------------------------------------------------------------------------------------------------------");
        for (Node node : graph) {
            node.addAttribute("ui.label", node.getId());

        }

        for (Edge e : graph.getEachEdge()) {
            e.addAttribute("ui.label", (Object) e.getAttribute("weight"));
        }

        DefaultComboBoxModel modelo = (DefaultComboBoxModel) cb_contactos2.getModel();
        DefaultComboBoxModel modelo1 = (DefaultComboBoxModel) cb_contactos1.getModel();
        modelo1.addElement(new Usuario("Mi posicion actual"));
        for (Usuario l : listaUsuarios) {
            modelo.addElement(l);
            modelo1.addElement(l);

        }

        cb_contactos2.setModel(modelo);
        cb_contactos1.setModel(modelo1);

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel(new GridLayout()) {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(600, 600);
            }
        };
        panel.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        Viewer viewer = new Viewer(graph, Viewer.ThreadingModel.GRAPH_IN_GUI_THREAD);
        viewer.enableAutoLayout();
        ViewPanel viewPanel = viewer.addDefaultView(false);
        panel.add(viewPanel);

       
        frame.add(panel);
        frame.pack();
        jp_grafo.add(panel, BorderLayout.CENTER);

        this.jd_grafo.setModal(true);
        jd_grafo.pack();
        jd_grafo.setLocationRelativeTo(this);
        jd_grafo.setVisible(true);


    }//GEN-LAST:event_jb_salirContactoMouseClicked

    private void jb_cercania1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_cercania1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jb_cercania1ActionPerformed
 //Funcion Boton Establecer Cercanias
/*
    Despliega un JDialog el cual es el que maneja todas las arista, desde aqui se crean las aristas
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Para que no genere un nodo igual a la posicion actual compara si el contador incial es 0
    
     */
    private void jb_establecerCercaniasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_establecerCercaniasMouseClicked
        // TODO add your handling code here:
        if (cont == 0) {
            graph.addNode("Mi posicion actual");
        }
        cont++;

        jl_viveYo.setModel(new DefaultListModel());
        jl_vive1.setModel(new DefaultListModel());
        jl_vive2.setModel(new DefaultListModel());

        DefaultListModel modelo = (DefaultListModel) jl_viveYo.getModel();
        DefaultListModel modelo2 = (DefaultListModel) jl_vive1.getModel();
        DefaultListModel modelo3 = (DefaultListModel) jl_vive2.getModel();

        for (Usuario l : listaUsuarios) {
            modelo.addElement(l);
            modelo2.addElement(l);
            modelo3.addElement(l);

        }
        jl_viveYo.setModel(modelo);
        jl_vive1.setModel(modelo2);
        jl_vive2.setModel(modelo3);

        jd_cercania.setModal(true);
        jd_cercania.pack();
        jd_cercania.setLocationRelativeTo(this);
        jd_cercania.setVisible(true);


    }//GEN-LAST:event_jb_establecerCercaniasMouseClicked
//Funcion Boton Establecer Cercanias Yo-Contacto
/*
    Crea una Arista para el grafo, esta Arista es la Mi Posicion Actual con cualquier contacto
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si no introduce ninguna distancia no creara ninguna Arista,
             Si la arista ya fue creada entonces se emite un mensaje de advertencia
    
     */
    private void jb_cercania1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_cercania1MouseClicked
        // TODO add your handling code here:

        boolean agregado = true;

        if (tf_distancia1.getText().equals("")) {
            JOptionPane.showMessageDialog(jd_cercania, "No ingreso ningun valor en la distancia");
        } else {
            try {
                graph.addEdge("Mi posicion actual" + jl_viveYo.getSelectedValue().getNombre(), "Mi posicion actual", jl_viveYo.getSelectedValue().getNombre()).addAttribute("length", Integer.parseInt(tf_distancia1.getText()));
                graph.getEdge("Mi posicion actual" + jl_viveYo.getSelectedValue().getNombre()).addAttribute("weight", Integer.parseInt(tf_distancia1.getText()));
            } catch (Exception e) {
                agregado = false;
            }

            if (agregado) {
                Arista arista = new Arista("Mi posicion actual" + jl_viveYo.getSelectedValue().getNombre(), "Mi posicion actual", jl_viveYo.getSelectedValue().getNombre(), jl_viveYo.getSelectedValue().getNombre() + "Mi posicion actual");
                arista.setPeso(Integer.parseInt(tf_distancia1.getText()));

                listaArista.add(arista);
                JOptionPane.showMessageDialog(jd_cercania, "Se establecio con exito");
            } else {
                JOptionPane.showMessageDialog(jd_cercania, "Esta arista ya habia sido creada");
            }
        }


    }//GEN-LAST:event_jb_cercania1MouseClicked

    private void jb_establecerCercaniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_establecerCercaniasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jb_establecerCercaniasActionPerformed

    private void jb_cercania2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_cercania2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jb_cercania2ActionPerformed
//Funcion Boton Establecer Cercanias Contacto-Contacto
/*
    Crea una Arista para el grafo, esta Arista es cualquier contacto con cualquier contacto
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: Si no introduce ninguna distancia no creara ninguna Arista,
             Si la arista ya fue creada entonces se emite un mensaje de advertencia
    
     */
    private void jb_cercania2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_cercania2MouseClicked
        // TODO add your handling code here
        boolean agregado = true;

        if (tf_distancia2.getText().equals("")) {
            JOptionPane.showMessageDialog(jd_cercania, "No ingreso ningun valor en la distancia");
        } else {
            try {
                graph.addEdge(jl_vive1.getSelectedValue().getNombre() + jl_vive2.getSelectedValue(), jl_vive1.getSelectedValue().getNombre(), jl_vive2.getSelectedValue().getNombre()).addAttribute("length", Integer.parseInt(tf_distancia2.getText()));
                graph.getEdge(jl_vive1.getSelectedValue().getNombre() + jl_vive2.getSelectedValue()).addAttribute("weight", Integer.parseInt(tf_distancia2.getText()));
            } catch (Exception e) {
                agregado = false;
            }

            if (agregado) {
                Arista arista = new Arista(jl_vive1.getSelectedValue().getNombre() + jl_vive2.getSelectedValue().getNombre(), jl_vive1.getSelectedValue().getNombre(), jl_vive2.getSelectedValue().getNombre(), jl_vive2.getSelectedValue().getNombre() + jl_vive1.getSelectedValue().getNombre());
                arista.setPeso(Integer.parseInt(tf_distancia2.getText()));
                listaArista.add(arista);
                JOptionPane.showMessageDialog(jd_cercania, "Se establecio con exito");
            } else {
                JOptionPane.showMessageDialog(jd_cercania, "Esta arista ya habia sido creada");
            }
        }


    }//GEN-LAST:event_jb_cercania2MouseClicked
//Funcion Ruta mas corta
/*
    Calcula cual es la ruta mas corta para la relacion Yo-contacto o Contacto-Contacto utilizando el algoritmo
    de Dijkstra. Marca los nodos en el grafo
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: 
    
     */
    private void jb_calcularRutaCortaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_calcularRutaCortaMouseClicked
        graph.clearAttributes();
        jb_ruta.setText("--------------------------------------------------------------------------------------------------------------------------");

        Usuario temp2 = ((Usuario) cb_contactos2.getSelectedItem());
        Usuario temp1 = ((Usuario) cb_contactos1.getSelectedItem());
        Dijkstra dijkstra = new Dijkstra(Dijkstra.Element.EDGE, "result", "length");

        dijkstra.init(graph);
        dijkstra.setSource(graph.getNode(temp1.getNombre()));
        dijkstra.compute();

        String acum = "";
        for (int i = 1; i < dijkstra.getPath(graph.getNode(temp2.getNombre())).toString().length() - 1; i++) {
            acum += dijkstra.getPath(graph.getNode(temp2.getNombre())).toString().charAt(i) + "";

        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {

        }
        for (Node node : dijkstra.getPathNodes(graph.getNode(temp2.getNombre()))) {

            node.addAttribute("ui.style", "fill-color: red;");

        }
        jb_ruta1.setText("Desde " + dijkstra.getSource() + " hasta " + temp2.getNombre() + " la mejor ruta es: " + acum);
        jb_ruta.setText("Desde " + dijkstra.getSource() + " hasta " + temp2.getNombre() + " la mejor distancia es: " + dijkstra.getPathLength(graph.getNode(temp2.getNombre())) + " km");

    

    }//GEN-LAST:event_jb_calcularRutaCortaMouseClicked
//Funcion Boton Abrir Jdialog COntacto Nuevo
/*
    Abre un Jdialog en el cual se crea un nuevo usuario
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: 
    
     */
    private void jb_nuevoContactoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_nuevoContactoMouseClicked
        this.jd_asignarUsuario.setModal(true);
        jd_asignarUsuario.pack();
        jd_asignarUsuario.setLocationRelativeTo(this);
        jd_asignarUsuario.setVisible(true);
    }//GEN-LAST:event_jb_nuevoContactoMouseClicked
//Funcion Salida Rapida con Contactos
/*
    Calcula la ruta general mas corta utilizando el algortimo de Prim, marca en el grafo esta ruta
  
    Parametros: Evento del mouse, sirve para inicializar el mouseclicked
    
    Retorna:
    
    Errores: 
    
     */
    private void jb_salidaRapidaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_salidaRapidaMouseClicked
        graph.clearAttributes();
        jb_ruta.setText("--------------------------------------------------------------------------------------------------------------------------");
        jb_ruta1.setText("--------------------------------------------------------------------------------------------------------------------------");
        String css = "edge .notintree {size:1px;fill-color:gray;} "
                + "edge .intree {size:3px;fill-color:red;}";

        graph.addAttribute("ui.stylesheet", css);

        Prim prim = new Prim("ui.class", "intree", "notintree");

        prim.init(graph);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {

        }

        prim.compute();


    }//GEN-LAST:event_jb_salidaRapidaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Inicio_boton;
    private javax.swing.JComboBox<String> cb_contactos1;
    private javax.swing.JComboBox<Usuario> cb_contactos2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JButton jb_agregarUsuario;
    private javax.swing.JButton jb_calcularRutaCorta;
    private javax.swing.JButton jb_cercania1;
    private javax.swing.JButton jb_cercania2;
    private javax.swing.JButton jb_establecerCercanias;
    private javax.swing.JButton jb_nuevoContacto;
    private javax.swing.JButton jb_refrescar;
    private javax.swing.JLabel jb_ruta;
    private javax.swing.JLabel jb_ruta1;
    private javax.swing.JButton jb_salidaRapida;
    private javax.swing.JButton jb_salirContacto;
    private javax.swing.JDialog jd_asignarUsuario;
    private javax.swing.JDialog jd_cercania;
    private javax.swing.JDialog jd_grafo;
    private javax.swing.JDialog jd_menu;
    private javax.swing.JList<Usuario> jl_amigos;
    private javax.swing.JList<Usuario> jl_vive1;
    private javax.swing.JList<Usuario> jl_vive2;
    private javax.swing.JList<Usuario> jl_viveYo;
    private javax.swing.JLabel jlb_nombre;
    private javax.swing.JMenuItem jm_abrirArchivo;
    private javax.swing.JMenuItem jm_eliminar;
    private javax.swing.JMenuItem jm_guardarArchivo;
    private javax.swing.JPanel jp_grafo;
    private javax.swing.JPopupMenu jpp_contactos;
    private javax.swing.JTextField tf_celular;
    private javax.swing.JTextField tf_distancia1;
    private javax.swing.JTextField tf_distancia2;
    private javax.swing.JTextField tf_nombre;
    private javax.swing.JTextField tf_nombreContacto;
    // End of variables declaration//GEN-END:variables
Graph graph = new SingleGraph("Grafo");
    int cont = 0;
    String nombrePrincipal, celularPrincipal;
    ArrayList<Usuario> listaUsuarios = new ArrayList();
    String ruta = "";
    File archivo = new File(ruta + ".txt");
    ArchivoUsuario archivoUsuario = new ArchivoUsuario();
    ArrayList<Arista> listaArista = new ArrayList();

}
