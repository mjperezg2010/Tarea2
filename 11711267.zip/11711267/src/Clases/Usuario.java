/*
Titulo: Clase Usuario

Funcion: contiene los metodos para el Usuario(COntacto) del programa

Fecha: 13 de agosto del 2018

Elaborado por: Martín José Pérez Gálvez
 */
package Clases;

public class Usuario {

    private String nombre;

    //Constructor Usuario
/*
    Aqui se incializa el nombre del usuario
  
    Parametros: String nombre; es el nombre que se le asignara al Usuario
    
    Retorna:
    
    Errores: 
    
     */
    public Usuario(String nombre) {
        this.nombre = nombre;
    }

     //Funcion get Nombre
/*
    Aqui se devuelve el nombre del Usuario
  
    Parametros: 
    
    Retorna: nombre, que es el nombre del Usuario
    
    Errores: 
    
     */
    public String getNombre() {
        return nombre;
    }
     //to String de Usuario
/*
    Aqui se escribre el string que tendra el objeto Usuario
  
    Parametros: 
    
    Retorna: el string que sera nombre del Usuario
    
    Errores: 
    
     */

    @Override
    public String toString() {
        return nombre;
    }
}
