/*
Titulo: Clase Arista

Funcion: Contiene las funciones que administran una arista

Fecha: 13 de agosto del 2018

Elaborado por: Martín José Pérez Gálvez
 */
package Clases;

public class Arista {
    private String edge,usuario1,usuario2,edge2;
    private int peso;

    //Constructor clase Arista con arista invertida
/*
   Se incializan las variables de la clase arista
  
    Parametros: String edge,usuario1,usuario2,edge2; que son los nodos y la arista normal e invertida
    
    Retorna: 
    
    Errores: 
    
     */
    public Arista(String edge, String usuario1, String usuario2, String edge2) {
        this.edge = edge;
        this.usuario1 = usuario1;
        this.usuario2 = usuario2;
        this.edge2 = edge2;
    }
    
     //Constructor clase Arista con usuarios
/*
   Se incializan los usuarios
  
    Parametros: String usuario1,usuario2; que son los nodos del grafo
    
    Retorna: 
    
    Errores: 
    
     */

    public Arista(String usuario1, String usuario2) {
        this.usuario1 = usuario1;
        this.usuario2 = usuario2;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

     //Constructor clase Arista con peso y usuarioa
/*
   Se incializan las variables de la clase arista, peso y usuarios
  
    Parametros: String peso,usuario1,usuario2,edge2; que son los nodos y el peso de la arista
    
    Retorna: 
    
    Errores: 
    
     */
    public Arista(String usuario1, String usuario2, int peso) {
        this.usuario1 = usuario1;
        this.usuario2 = usuario2;
        this.peso = peso;
    }

    

    //Constructo vacio

    public Arista() {
    }

    
     //Funcion getEdge1 de la Arista
/*
   Se devuelve la Arista normal 
  
    Parametros: 
    
    Retorna: La arista normal
    
    Errores: 
    
     */
    public String getEdge() {
        return edge;
    }
    
     //Funcion setEdge1 de la Arista
/*
   Se asifna la Arista normal 
  
    Parametros: String edge, que es la arista normal 
    
    Retorna: 
    
    Errores: 
    
     */

    public void setEdge(String edge) {
        this.edge = edge;
    }

    
     //Funcion getUsuario1 de la Arista
/*
   Se devuelve el usuario1(nodo1) de la Arista
  
    Parametros: 
    
    Retorna: El nodo 1
    
    Errores: 
    
     */
    public String getUsuario1() {
        return usuario1;
    }
    
      //Funcion setUsuario1 de la Arista
/*
   Se asigna el usuario1(nodo1) de la Arista
  
    Parametros: String usuario1, que es el nodo 1
    
    Retorna: 
    
    Errores: 
    
     */

    public void setUsuario1(String usuario1) {
        this.usuario1 = usuario1;
    }
    
      //Funcion getUsuario2 de la Arista
/*
   Se devuelve el usuario2(nodo2) de la Arista
  
    Parametros: 
    
    Retorna: El nodo 2
    
    Errores: 
    
     */

    public String getUsuario2() {
        return usuario2;
    }

     //Funcion setUsuario1 de la Arista
/*
   Se asigna el usuario1(nodo1) de la Arista
  
    Parametros: String usuario1, que es el nodo 1
    
    Retorna: 
    
    Errores: 
    
     */
    public void setUsuario2(String usuario2) {
        this.usuario2 = usuario2;
    }
    
      //Funcion getEdge2 de la Arista
/*
   Se devuelve la Arista invertida 
  
    Parametros: 
    
    Retorna: La arista invertida
    
    Errores: 
    
     */

    public String getEdge2() {
        return edge2;
    }
     //Funcion setEdge2 de la Arista
/*
   Se asifna la Arista invertida 
  
    Parametros: String edge2, que es la arista invertida
    
    Retorna: 
    
    Errores: 
    
     */
  

    public void setEdge2(String edge2) {
        this.edge2 = edge2;
    }
    
     //Funcion completar
/*
   crea la arista normal e invertida a partir de los usuarios 
  
    Parametros: 
    
    Retorna: 
    
    Errores: 
    
     */
    
    public void completar(){
        this.edge=this.usuario1+this.usuario2;
        this.edge2=this.usuario2+this.usuario1;
    }
    
    
    
    
}
